-- MySQL dump 10.13  Distrib 5.7.20, for Win64 (x86_64)
--
-- Host: localhost    Database: webservice
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `cpf` varchar(15) NOT NULL,
  `endereco` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (2,'MARIA PEDROSA','555.555.555-99','RUA PESTANA, 158'),(3,'FABIANA GOLVEIA','888.888.666-44','TRAV. LONDRINA, 400'),(4,'Fernanda Dias','999.999.999.00','RUA VINTE E CINCO, 300'),(5,'Juliana Pacheco','000.000.000-00','AV INDEPENDENCIA, 1000'),(6,'Jonas Pedro da Silva','000.000.000-00','AV INDEPENDENCIA, 1000'),(7,'Chun-Li','101.101.101.10','Street Fighter, 111'),(8,'Josemar Gomes','789.456.123.99','Rua Florestal, 200'),(9,'Joselito Epaminondas','454.545.400-66','Av. Vinte e Oito, 28'),(10,'Roberto Justus','123.456.789-00','Av. da Riqueza, 1000000'),(11,'Luiz Antonio de Oliveira','451.556.999-99','AV. BUSSOCABA, 11'),(12,'Fernando Romero','774.999.874-22','RUA SAO ROQUE, 777'),(13,'Rogerio Alcantara','101.888.222-77','Rua Sem Saída, 666'),(14,'Xispirito Chapolin','000.000.000-88','Av. Libertador, 22'),(15,'Janete da Silva','777.444.111-22','RUA PESTANA, 158'),(16,'Florinda Alves','777.666.777-22','Rua Sem Saída, 666'),(17,'Florinda Mesa','222.112.660-55','Trav. Aerolitos, 111'),(18,'Florinda','777.111.321-82','Av. Novo Mexico, 10'),(19,'Sr. Madruga','888.999.221-91','Vila do Chaves'),(20,'Chico Bento','111.000.000-00','Rua das Laranjeiras, 451'),(21,'Cebolinha','444.555.666-88','Rua das Laranjeiras, 562');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-13 16:07:11
