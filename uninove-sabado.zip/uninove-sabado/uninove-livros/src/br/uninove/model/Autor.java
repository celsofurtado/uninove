package br.uninove.model;

public class Autor {

	private int codigoAutor;
	private String nomeAutor;
	private String cidadeAutor;

	public int getCodigoAutor() {
		return codigoAutor;
	}

	public void setCodigoAutor(int codigoAutor) {
		this.codigoAutor = codigoAutor;
	}

	public String getNomeAutor() {
		return nomeAutor;
	}

	public void setNomeAutor(String nomeAutor) {
		this.nomeAutor = nomeAutor;
	}

	public String getCidadeAutor() {
		return cidadeAutor;
	}

	public void setCidadeAutor(String cidadeAutor) {
		this.cidadeAutor = cidadeAutor;
	}

}
