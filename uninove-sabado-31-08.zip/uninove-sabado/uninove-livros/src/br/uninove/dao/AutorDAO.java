package br.uninove.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import br.uninove.model.Autor;

public class AutorDAO {

	private Autor autor;
	
	public AutorDAO() {}
	
	public AutorDAO(Autor autor) {
		this.autor = autor;
	}
	
	public List<Autor> getAutores() {
		
		//*** Consulta sql no banco
		String consulta = "SELECT * FROM tbl_autor";
		
		//*** Objeto que recebe o resultado da consulta
		ResultSet rs = null;
		
		try {
			
			//*** Preparando para enviar 
			//*** o comando para o banco
			PreparedStatement stm = Conexao.getConexao().prepareStatement(consulta);
			rs = stm.executeQuery();
			
			while (rs.next()) {
				System.out.println(rs.getString("nome_autor") + " - " + rs.getString("cidade_autor"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}
	
}











