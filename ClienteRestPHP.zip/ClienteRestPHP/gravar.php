<?php

	// *** RECUPERAR OS DADOS DO FORMULÁRIO
	$nome = $_GET['txt-nome'];
	$cpf = $_GET['txt-cpf'];
	$endereco = $_GET['txt-endereco'];
	$op = $_GET['txt-op'];
	
	// *** URL DA API JAVA - REST WEBSERVICE
	if ($op == 'novo'){
		$id = 0;
		$url = "http://localhost:8080/RestFul/cliente/gravar";
	} else {
		$id = $_GET['txt-id'];
		$url = "http://localhost:8080/RestFul/cliente/atualizar";
	}
	
	// *** INICIANDO O cURL
	$ch = curl_init($url);
	
	// *** CRIA UM ARRAY COM OS DADOS QUE SERÃO ENVIADOS VIA JSON
	$jsonData = array(
		'id' => $id,
		'nome' => $nome,
		'cpf' => $cpf,
		'endereco' => $endereco
	);
	
	// *** CRIAR UMA REPRESENTAÇÃO JSON DO ARRAY
	$jsonDataEncoded = json_encode($jsonData);
	
	// *** DIZ AO CURL QUE SE DESEJA ENVIAR UMA REQUISIÇÃO DO TIPO POST
	curl_setopt($ch, CURLOPT_POST, 1);
	
	// *** ANEXAMOS A STRING JSON ENCODADA AOS CAMPOS DO POST
	curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
	
	// *** DEFINIMOS O CONTENT-TYPE PARA application/json
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
	
	// *** EXECUTAMOS A REQUISIÇÃO
	$result = curl_exec($ch);
	
	header('location: http://localhost/CELSO/index.php');

?>