<?php
		$id = $_GET['id'];
		
		// *** ENDEREÇO DO RECURSO WEBSERVICE
		$url = "http://localhost:8080/RestFul/cliente/excluirCliente/$id/";
		
		// *** ENVIO DE UM REQUEST AO RECURSO
		$cliente = curl_init($url);
		curl_setopt($cliente, CURLOPT_RETURNTRANSFER, 1);
		
		// *** OBTER A RESPOSTA DO RECURSO
		$response = curl_exec($cliente);
		
		// *** DECODE - TRANSFORMAR EM UM OBJETO PHP
		$resultado = json_decode($response);
?>