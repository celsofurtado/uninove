package br.senai.sp.resource;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.senai.sp.controller.ClienteController;
import br.senai.sp.model.Cliente;

@Path("/cliente")
public class ClienteResource {

	@GET
	@Path("/listarTodos")
	//@Produces("application/json")
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Cliente> listarTodos(){
		return new ClienteController().listarTodos();
	}
	
	@GET
	@Produces("application/json")
	@Path("/listarCliente/{id}/")
	public Cliente listarCliente(@PathParam("id") int id) {
		return new ClienteController().listarCliente(id);
	}
	
	@POST
	@Consumes("application/json")
	@Path("/gravar")
	public Response gravar(Cliente cliente){
		System.out.println(cliente.toString());
		System.out.println(cliente.getId());
		System.out.println(cliente.getNome());
		System.out.println(cliente.getCpf());
		System.out.println(cliente.getEndereco());
		
		new ClienteController().gravar(cliente);
		
		return Response.status(Response.Status.OK).build();
	}
	
	@POST
	@Consumes("application/json")
	@Path("/atualizar")
	public Response atualizar(Cliente cliente) {
		new ClienteController().atualizar(cliente);
		return Response.status(Response.Status.OK).build();
	}

}
