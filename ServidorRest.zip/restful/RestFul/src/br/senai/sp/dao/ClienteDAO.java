package br.senai.sp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import br.senai.sp.factory.ConnectionFactory;
import br.senai.sp.model.Cliente;

public class ClienteDAO extends ConnectionFactory {
	
	private static ClienteDAO instance;
	
	
	private ClienteDAO() {
		
	}

	public static synchronized ClienteDAO getInstance() {
		if (instance == null) {
			instance = new ClienteDAO();
		}
		return instance;
	}
	
	public ArrayList<Cliente> listarTodos(){
		
		ArrayList<Cliente> clientes = new ArrayList<>();
		
		Connection conexao = null;
		conexao = criarConexao();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;		
		
		try {
			pstmt = conexao.prepareStatement("select * from cliente order by id DESC");
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Cliente cliente = new Cliente();
				cliente.setNome(rs.getString("nome"));
				cliente.setCpf(rs.getString("cpf"));
				cliente.setEndereco(rs.getString("endereco"));
				cliente.setId(rs.getInt("id"));
				clientes.add(cliente);
			}
			
		} catch (Exception e) {
			System.out.println("Erro ao listar todos os clientes.");
			e.printStackTrace();
		}finally {
			fecharConexao(conexao, pstmt, rs);
		}
		
		return clientes;
	}
	
	public Cliente listarCliente(int id){
		
		Cliente cliente = new Cliente();
		
		Connection conexao = null;
		conexao = criarConexao();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;		
		
		try {
			pstmt = conexao.prepareStatement("select * from cliente where id = ?");
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				cliente.setNome(rs.getString("nome"));
				cliente.setCpf(rs.getString("cpf"));
				cliente.setEndereco(rs.getString("endereco"));
				cliente.setId(rs.getInt("id"));
			}
			
		} catch (Exception e) {
			System.out.println("Erro ao listar todos os clientes.");
			e.printStackTrace();
		}finally {
			fecharConexao(conexao, pstmt, rs);
		}
		
		return cliente;
	}
	
	public boolean gravar(Cliente cliente) {
		Connection conexao = null;
		conexao = criarConexao();
		
		PreparedStatement pstmt = null;
		
		String sql = "INSERT INTO cliente (nome, cpf, endereco) VALUES (?, ?, ?)";
		
		try {
			pstmt = conexao.prepareStatement(sql);
			pstmt.setString(1, cliente.getNome());
			pstmt.setString(2, cliente.getCpf());
			pstmt.setString(3, cliente.getEndereco());
			pstmt.execute();	
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean atualizar(Cliente cliente) {
		Connection conexao = null;
		conexao = criarConexao();
		
		PreparedStatement pstmt = null;
		
		String sql = "UPDATE cliente SET nome = ?, cpf = ?, endereco = ? WHERE id = ?";
		
		try {
			pstmt = conexao.prepareStatement(sql);
			pstmt.setString(1, cliente.getNome());
			pstmt.setString(2, cliente.getCpf());
			pstmt.setString(3, cliente.getEndereco());
			pstmt.setInt(4, cliente.getId());
			pstmt.execute();			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

}
