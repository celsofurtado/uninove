package br.senai.sp.controller;

import java.util.ArrayList;

import br.senai.sp.dao.ClienteDAO;
import br.senai.sp.model.Cliente;

/**
 * 
 * Classe repons�vel por ser o controlador entre o resource e a camada DAO
 * 
 * @return
 * @author Celso M. Furtado <celso@celsofurtaod.pro.br>
 * @since 30/10/2018 13:54
 * @version 1.0
 */
public class ClienteController {
	
	public ArrayList<Cliente> listarTodos(){
		return ClienteDAO.getInstance().listarTodos();
	}
	
	public Cliente listarCliente(int id) {
		return ClienteDAO.getInstance().listarCliente(id);
	}
	
	public boolean gravar(Cliente cliente) {
		return ClienteDAO.getInstance().gravar(cliente);
	}
	
	public boolean atualizar(Cliente cliente) {
		return ClienteDAO.getInstance().atualizar(cliente);
	}

}
