package br.uninove.teste;

import br.uninove.model.Autor;
import br.uninove.model.Livro;

public class Teste {

	public static void main(String[] args) {
		
		Autor machado = new Autor();
		machado.setNomeAutor("Machado de Assis");
		machado.setCidadeAutor("Rio de Janeiro");
		machado.setCodigoAutor(1000);
		
		Autor cora = new Autor();
		cora.setNomeAutor("Cora Coralina");
		cora.setCidadeAutor("Recife");
		cora.setCodigoAutor(1200);
		
		Livro amorPerdicao = new Livro();
		amorPerdicao.setAnoEdicao("1954");
		amorPerdicao.setTituloLivro("Amor de Perdi��o");
		amorPerdicao.setCodigoLivro(1245);
		amorPerdicao.setAutor(machado);
		
		System.out.println(amorPerdicao.getAutor().getNomeAutor());
		
		
		

	}

}
