<?php

echo 'Teste';