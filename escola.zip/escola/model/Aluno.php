<?php

class Aluno {

    private $conexao;
    private $tabela = 'tbl_aluno';

    // Propriedades do aluno
    public $id;
    public $nome;
    public $nota1;
    public $nota2;

    // Contrutor do objeto Aluno
    public function __construct($con){
        $this->conexao = $con;
    }

    // Método retornar lista de alunos do banco
    public function getAlunos(){
        // Query de consulta na tabela alunos
        $sql = 'SELECT * FROM ' . $this->tabela;

        // Criar o statement
        $stmt = $this->conexao->prepare($sql);

        // Executar o comando sql no banco
        $stmt->execute();

        return $stmt;
    }

}

