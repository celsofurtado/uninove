<?php

class Aluno {

    private $conexao;
    private $tabela = 'tbl_aluno';

    // Propriedades do aluno
    public $id;
    public $nome;
    public $nota1;
    public $nota2;

    // Contrutor do objeto Aluno
    public function __construct($con){
        $this->conexao = $con;
    }

    // Método retornar lista de alunos do banco
    public function getAlunos(){
        // Query de consulta na tabela alunos
        $sql = 'SELECT * FROM ' . $this->tabela;

        // Criar o statement
        $stmt = $this->conexao->prepare($sql);

        // Executar o comando sql no banco
        $stmt->execute();

        return $stmt;
    }

    // Método para retornar um aluno
    public function getAluno(){
        // Query de consulta na tabela alunos
        $sql = 'SELECT * FROM ' . $this->tabela . ' WHERE id = ?';

        // Criar o statement
        $stmt = $this->conexao->prepare($sql);

        // Carregar o id
        $stmt->bindParam(1, $this->id);

        // Executar o comando sql no banco
        $stmt->execute();

        $aluno = $stmt->fetch(PDO::FETCH_ASSOC);

        $this->nome = $aluno["nome"];
        $this->nota1 = $aluno["nota1"];
        $this->nota2 = $aluno["nota2"];
        
    }

}

