var alunos = document.querySelectorAll("#aluno");

for (var i = 0; i < alunos.length; i++){
  var trAluno = alunos[i];

  var tdNota1 = trAluno.querySelector("#nota1");
  var tdNota2 = trAluno.querySelector("#nota2");

  var nota1 = tdNota1.textContent;
  var nota2 = tdNota2.textContent;

  var media = (parseInt(nota1) + parseInt(nota2)) / 2;

  var tdMedia = trAluno.querySelector("#media");

  tdMedia.textContent = media;

  var tdSituacao = trAluno.querySelector("#situacao");

  if (media >= 5){
    tdSituacao.textContent = "APROVADO";
    trAluno.classList.add("table-success");
  } else {
    tdSituacao.textContent = "REPROVADO";
    trAluno.classList.add("table-danger");
  }

}

















