function validarNota1(nota1){
    if (nota1 >= 0 && nota1 <= 10){
        return true;
    } else {
        return false;
    }
}

function validarNota2(nota2){
    if (nota2 >= 0 && nota2 <= 10){
        return true;
    } else {
        return false;
    }
}